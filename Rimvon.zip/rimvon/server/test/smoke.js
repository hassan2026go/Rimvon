'use strict';
// Smoke test: starts the server on a temp port/data dir and exercises the main flows.
const { spawn } = require('child_process');
const path = require('path');
const os = require('os');
const fs = require('fs');
const crypto = require('crypto');
const WebSocket = require('ws');

const PORT = 18080 + Math.floor(Math.random() * 500);
const DATA = fs.mkdtempSync(path.join(os.tmpdir(), 'rimvon-'));
const srv = spawn('node', [path.join(__dirname, '..', 'server.js')], {
  env: { ...process.env, PORT: String(PORT), DATA_DIR: DATA, HOST: '127.0.0.1' }, stdio: 'inherit',
});
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const fakePub = () => crypto.randomBytes(91).toString('base64'); // 124 chars

function client() {
  const ws = new WebSocket('ws://127.0.0.1:' + PORT);
  const inbox = [];
  const waiters = [];
  ws.on('message', (d) => {
    const m = JSON.parse(d.toString());
    const i = waiters.findIndex((w) => w.pred(m));
    if (i >= 0) waiters.splice(i, 1)[0].res(m); else inbox.push(m);
  });
  const open = new Promise((r) => ws.on('open', r));
  const send = (o) => ws.send(JSON.stringify(o));
  const wait = (pred, ms = 3000) => {
    const i = inbox.findIndex(pred);
    if (i >= 0) return Promise.resolve(inbox.splice(i, 1)[0]);
    return new Promise((res, rej) => {
      const w = { pred, res };
      waiters.push(w);
      setTimeout(() => { const k = waiters.indexOf(w); if (k >= 0) { waiters.splice(k, 1); rej(new Error('timeout')); } }, ms);
    });
  };
  return { ws, open, send, wait };
}
let failed = 0;
const ok = (c, name) => { console.log((c ? 'PASS ' : 'FAIL ') + name); if (!c) failed++; };
const fp = (p) => crypto.createHash('sha256').update(Buffer.from(p, 'base64')).digest('base64').slice(0, 16);

(async () => {
  await sleep(600);
  const pubA = fakePub(), pubB = fakePub();
  const a = client(); await a.open;
  a.send({ type: 'signup', pub: pubA, auth: 'secret-a-123' });
  const ra = await a.wait((m) => m.type === 'ready');
  ok(/^\d{10}$/.test(ra.id), 'signup returns 10-digit number ' + ra.id);

  const b = client(); await b.open;
  b.send({ type: 'signup', pub: pubB, auth: 'secret-b-123' });
  const rb = await b.wait((m) => m.type === 'ready');

  // bad login
  const x = client(); await x.open;
  x.send({ type: 'login', id: ra.id, auth: 'wrong-pass', pub: pubA });
  ok((await x.wait((m) => m.type === 'err')).code === 'auth', 'wrong password rejected');

  // lookup
  a.send({ type: 'lookup', id: rb.id });
  const lk = await a.wait((m) => m.type === 'lookup');
  ok(lk.exists && lk.pub === pubB, 'lookup returns public key');
  a.send({ type: 'lookup', id: '1234567890' });
  ok(!(await a.wait((m) => m.type === 'lookup')).exists, 'lookup unknown number');

  // message with wrong recipient key -> nack key
  a.send({ type: 'msg', to: rb.id, mid: 'mid-00000001', env: 'x'.repeat(40), rk: 'WRONGWRONGWRONG1' });
  const nk = await a.wait((m) => m.type === 'nack');
  ok(nk.reason === 'key' && nk.pub === pubB, 'stale key gets nack(key) with fresh pub');

  // delivery
  a.send({ type: 'msg', to: rb.id, mid: 'mid-00000001', env: 'x'.repeat(40), rk: fp(pubB) });
  ok(!!(await a.wait((m) => m.type === 'sent')), 'server confirms sent');
  const got = await b.wait((m) => m.type === 'msg');
  ok(got.from === ra.id && got.fpub === pubA && got.mid === 'mid-00000001', 'recipient receives message with sender key');
  b.send({ type: 'ack', q: got.q });
  b.send({ type: 'rcpt', to: ra.id, mid: got.mid, st: 'd' });
  const rc = await a.wait((m) => m.type === 'rcpt');
  ok(rc.st === 'd' && rc.mid === got.mid, 'delivery receipt reaches sender');
  a.send({ type: 'ack', q: rc.q });

  // offline queue + redelivery until acked
  b.ws.close(); await sleep(200);
  a.send({ type: 'msg', to: rb.id, mid: 'mid-00000002', env: 'y'.repeat(40), rk: fp(pubB) });
  await a.wait((m) => m.type === 'sent');
  const b2 = client(); await b2.open;
  b2.send({ type: 'login', id: rb.id, auth: 'secret-b-123', pub: pubB });
  await b2.wait((m) => m.type === 'ready');
  const q1 = await b2.wait((m) => m.type === 'msg');
  ok(q1.mid === 'mid-00000002', 'offline message delivered after login');
  b2.ws.close(); await sleep(200);
  const b3 = client(); await b3.open;
  b3.send({ type: 'login', id: rb.id, auth: 'secret-b-123', pub: pubB });
  await b3.wait((m) => m.type === 'ready');
  const q2 = await b3.wait((m) => m.type === 'msg');
  ok(q2.mid === 'mid-00000002', 'un-acked message is redelivered');
  b3.send({ type: 'ack', q: q2.q });
  await sleep(150);

  // duplicate resend does not duplicate
  a.send({ type: 'msg', to: rb.id, mid: 'mid-00000003', env: 'z'.repeat(40), rk: fp(pubB) });
  a.send({ type: 'msg', to: rb.id, mid: 'mid-00000003', env: 'z'.repeat(40), rk: fp(pubB) });
  await b3.wait((m) => m.type === 'msg' && m.mid === 'mid-00000003');
  await sleep(300);
  ok(!(await b3.wait((m) => m.type === 'msg' && m.mid === 'mid-00000003', 300).catch(() => null)), 'duplicate mid is not delivered twice');

  // call signaling live
  a.send({ type: 'call', to: rb.id, env: 'offer-envelope' });
  const call = await b3.wait((m) => m.type === 'call');
  ok(call.from === ra.id && call.env === 'offer-envelope', 'call signal routed');

  // new device login replaces key and kicks the old session
  const pubA2 = fakePub();
  const a2 = client(); await a2.open;
  a2.send({ type: 'login', id: ra.id, auth: 'secret-a-123', pub: pubA2 });
  await a2.wait((m) => m.type === 'ready');
  ok(!!(await a.wait((m) => m.type === 'kicked')), 'old device is kicked');
  b3.send({ type: 'lookup', id: ra.id });
  ok((await b3.wait((m) => m.type === 'lookup')).pub === pubA2, 'new device key published');

  // unauthenticated traffic is refused
  const u = client(); await u.open;
  u.send({ type: 'msg', to: ra.id, mid: 'mid-00000009', env: 'q'.repeat(40), rk: 'x' });
  ok((await u.wait((m) => m.type === 'err')).code === 'noauth', 'unauthenticated message refused');

  // change password
  a2.send({ type: 'setpass', old: 'secret-a-123', auth: 'new-secret-456' });
  ok((await a2.wait((m) => m.type === 'ok')).for === 'setpass', 'password change');
  const a3 = client(); await a3.open;
  a3.send({ type: 'login', id: ra.id, auth: 'new-secret-456', pub: pubA2 });
  ok(!!(await a3.wait((m) => m.type === 'ready')), 'login with new password');

  // http endpoints
  const res = await fetch(`http://127.0.0.1:${PORT}/health`);
  ok(res.status === 200, 'health endpoint');
  const idx = await fetch(`http://127.0.0.1:${PORT}/`);
  ok(idx.status === 200 || idx.status === 404, 'static route responds');
  const trav = await fetch(`http://127.0.0.1:${PORT}/..%2f..%2fserver.js`);
  ok(trav.status !== 200, 'path traversal blocked');

  console.log(failed ? `\n${failed} FAILED` : '\nALL PASSED');
  srv.kill();
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.error('test crashed:', e); srv.kill(); process.exit(1); });
