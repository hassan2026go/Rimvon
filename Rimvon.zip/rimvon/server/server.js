'use strict';
/*
 * Rimvon relay server.
 *
 * - Accounts: 10-digit number + secret (scrypt-hashed). Public ECDH key per account.
 * - Messages/calls are end-to-end encrypted by the clients; this server only routes ciphertext.
 * - Offline store-and-forward queue (ciphertext only), deleted on client ack or after a TTL.
 * - No message history, no contact lists, no logs of who talks to whom.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');

const env = process.env;
const PORT = parseInt(env.PORT || '8080', 10);
const HOST = env.HOST || '0.0.0.0';
const DATA_DIR = env.DATA_DIR || path.join(__dirname, 'data');
const PUBLIC_DIR = path.join(__dirname, 'public');
const TRUST_PROXY = env.TRUST_PROXY === '1';
const MAX_PAYLOAD = 8 * 1024 * 1024;
const QUEUE_TTL_MS = parseFloat(env.QUEUE_TTL_DAYS || '7') * 86400000;
const CALL_TTL_MS = 45000;
const QUEUE_MAX_ITEMS = 500;
const QUEUE_MAX_BYTES = 24 * 1024 * 1024;
const TURN_URLS = (env.TURN_URLS || '').split(',').map((s) => s.trim()).filter(Boolean);
const TURN_SECRET = env.TURN_SECRET || '';
const STUN_URLS = (env.STUN_URLS || 'stun:stun.l.google.com:19302,stun:stun.cloudflare.com:3478')
  .split(',').map((s) => s.trim()).filter(Boolean);

fs.mkdirSync(DATA_DIR, { recursive: true, mode: 0o700 });

/* ---------- persistence ---------- */
function load(name, fallback) {
  try { return JSON.parse(fs.readFileSync(path.join(DATA_DIR, name), 'utf8')); } catch { return fallback; }
}
const accounts = new Map(Object.entries(load('accounts.json', {})));
const queues = new Map(Object.entries(load('queues.json', {})));
const sessions = new Map(); // id -> ws
const dirty = { accounts: false, queues: false };
let flushTimer = null;

function markDirty(k) {
  dirty[k] = true;
  if (!flushTimer) flushTimer = setTimeout(flush, 2000);
}
function flush() {
  flushTimer = null;
  for (const k of Object.keys(dirty)) {
    if (!dirty[k]) continue;
    dirty[k] = false;
    const src = k === 'accounts' ? accounts : queues;
    const file = path.join(DATA_DIR, k + '.json');
    const tmp = file + '.tmp';
    try {
      fs.writeFileSync(tmp, JSON.stringify(Object.fromEntries(src)), { mode: 0o600 });
      fs.renameSync(tmp, file);
    } catch (e) { console.error('persist failed', k, e.message); dirty[k] = true; }
  }
}

/* ---------- helpers ---------- */
const scryptRaw = (pw, salt) => new Promise((res, rej) =>
  crypto.scrypt(pw, salt, 32, { N: 16384, r: 8, p: 1 }, (e, k) => (e ? rej(e) : res(k))));
const DUMMY_SALT = crypto.randomBytes(16);
const fp = (pubB64) =>
  crypto.createHash('sha256').update(Buffer.from(pubB64, 'base64')).digest('base64').slice(0, 16);
const validPub = (p) => typeof p === 'string' && p.length >= 100 && p.length <= 200 && /^[A-Za-z0-9+/=]+$/.test(p);
const validAuth = (a) => typeof a === 'string' && a.length >= 6 && a.length <= 256;
const isId = (s) => typeof s === 'string' && /^\d{10}$/.test(s);
const newQ = () => crypto.randomBytes(9).toString('base64url');
const send = (ws, o) => { if (ws && ws.readyState === 1) ws.send(JSON.stringify(o)); };

const hits = new Map();
function hit(key, limit, windowMs) {
  const now = Date.now();
  let e = hits.get(key);
  if (!e || e.reset < now) { e = { n: 0, reset: now + windowMs }; hits.set(key, e); }
  e.n++;
  return e.n <= limit;
}
setInterval(() => { const n = Date.now(); for (const [k, e] of hits) if (e.reset < n) hits.delete(k); }, 60000).unref();
const fails = new Map(); // id -> {n, until}

function clientIp(req) {
  if (TRUST_PROXY) {
    const x = req.headers['x-forwarded-for'];
    if (x) return String(x).split(',')[0].trim();
  }
  return req.socket.remoteAddress || '?';
}

function iceServers(id) {
  const list = [];
  if (STUN_URLS.length) list.push({ urls: STUN_URLS });
  if (TURN_URLS.length && TURN_SECRET) {
    const username = Math.floor(Date.now() / 1000) + 86400 + ':' + id;
    const credential = crypto.createHmac('sha1', TURN_SECRET).update(username).digest('base64');
    list.push({ urls: TURN_URLS, username, credential });
  }
  return list;
}

/* ---------- queue ---------- */
function enqueue(to, item) {
  let arr = queues.get(to);
  if (!arr) { arr = []; queues.set(to, arr); }
  if (item.type === 'msg') {
    if (arr.some((x) => x.type === 'msg' && x.from === item.from && x.mid === item.mid)) return 'dup';
    let bytes = 0;
    for (const x of arr) if (x.env) bytes += x.env.length;
    if (bytes + item.env.length > QUEUE_MAX_BYTES) return 'full';
  }
  if (arr.length >= QUEUE_MAX_ITEMS) return 'full';
  arr.push(item);
  if (item.type !== 'call') markDirty('queues');
  return 'ok';
}
const expired = (x, now) => now - x.ts > (x.type === 'call' ? CALL_TTL_MS : QUEUE_TTL_MS);
function ackItem(id, q) {
  const arr = queues.get(id);
  if (!arr) return;
  const i = arr.findIndex((x) => x.q === q);
  if (i < 0) return;
  arr.splice(i, 1);
  if (!arr.length) queues.delete(id);
  markDirty('queues');
}
function flushQueue(id, ws) {
  const arr = queues.get(id);
  if (!arr) return;
  const now = Date.now();
  const keep = arr.filter((x) => !expired(x, now));
  if (keep.length !== arr.length) { keep.length ? queues.set(id, keep) : queues.delete(id); markDirty('queues'); }
  for (const x of keep) send(ws, x);
}
function push(to, item) {
  const s = sessions.get(to);
  if (s && s.readyState === 1) send(s, item);
}
setInterval(() => {
  const now = Date.now();
  for (const [id, arr] of queues) {
    const keep = arr.filter((x) => !expired(x, now));
    if (keep.length !== arr.length) { keep.length ? queues.set(id, keep) : queues.delete(id); markDirty('queues'); }
  }
}, 60000).unref();

/* ---------- auth ---------- */
function attach(ws, id) {
  const old = sessions.get(id);
  if (old && old !== ws) { send(old, { type: 'kicked' }); old.id = null; try { old.close(4003, 'replaced'); } catch {} }
  ws.id = id;
  sessions.set(id, ws);
  clearTimeout(ws.authTimer);
  send(ws, { type: 'ready', id, ice: iceServers(id) });
  flushQueue(id, ws);
}

async function checkAuth(id, auth) {
  const acc = accounts.get(id);
  const salt = acc ? Buffer.from(acc.salt, 'base64') : DUMMY_SALT;
  const h = await scryptRaw(auth, salt);
  if (!acc) return null;
  const good = Buffer.from(acc.hash, 'base64');
  return h.length === good.length && crypto.timingSafeEqual(h, good) ? acc : null;
}

async function onSignup(ws, m, ip) {
  if (ws.id) return;
  if (!hit('su:' + ip, 10, 3600e3)) return send(ws, { type: 'err', code: 'rate' });
  if (!validPub(m.pub) || !validAuth(m.auth)) return send(ws, { type: 'err', code: 'bad' });
  const salt = crypto.randomBytes(16);
  const hash = await scryptRaw(m.auth, salt);
  let id;
  do { id = String(crypto.randomInt(1e9, 1e10)); } while (accounts.has(id));
  accounts.set(id, {
    salt: salt.toString('base64'), hash: hash.toString('base64'),
    pub: m.pub, fp: fp(m.pub), created: Date.now(),
  });
  markDirty('accounts');
  attach(ws, id);
}

async function onLogin(ws, m, ip) {
  if (ws.id) return;
  const id = String(m.id || '');
  if (!isId(id) || !validAuth(m.auth) || !validPub(m.pub)) return send(ws, { type: 'err', code: 'bad' });
  if (!hit('lg:' + ip, 40, 600e3)) return send(ws, { type: 'err', code: 'rate' });
  const f = fails.get(id);
  if (f && f.until > Date.now()) return send(ws, { type: 'err', code: 'locked' });
  const acc = await checkAuth(id, m.auth);
  if (!acc) {
    const e = fails.get(id) || { n: 0, until: 0 };
    e.n++;
    if (e.n >= 8) { e.n = 0; e.until = Date.now() + 15 * 60000; }
    fails.set(id, e);
    return send(ws, { type: 'err', code: 'auth' });
  }
  fails.delete(id);
  if (acc.pub !== m.pub) { acc.pub = m.pub; acc.fp = fp(m.pub); markDirty('accounts'); }
  attach(ws, id);
}

/* ---------- message handling ---------- */
function onMsg(ws, m) {
  const to = String(m.to || '');
  const mid = String(m.mid || '');
  if (!isId(to) || !/^[\w-]{8,64}$/.test(mid) || typeof m.env !== 'string' || m.env.length < 20)
    return send(ws, { type: 'nack', mid, reason: 'bad' });
  const acc = accounts.get(to);
  if (!acc) return send(ws, { type: 'nack', mid, reason: 'nouser' });
  if (m.rk !== acc.fp) return send(ws, { type: 'nack', mid, reason: 'key', pub: acc.pub });
  const me = accounts.get(ws.id);
  const item = { type: 'msg', q: newQ(), from: ws.id, mid, env: m.env, ts: Date.now(), fpub: me.pub };
  const r = enqueue(to, item);
  if (r === 'full') return send(ws, { type: 'nack', mid, reason: 'full' });
  send(ws, { type: 'sent', mid });
  if (r === 'ok') push(to, item);
}

function onRcpt(ws, m) {
  const to = String(m.to || '');
  if (!isId(to) || !accounts.has(to) || (m.st !== 'd' && m.st !== 'r')) return;
  if (!/^[\w-]{8,64}$/.test(String(m.mid || ''))) return;
  const item = { type: 'rcpt', q: newQ(), from: ws.id, mid: m.mid, st: m.st, ts: Date.now() };
  if (enqueue(to, item) === 'ok') push(to, item);
}

function onCall(ws, m) {
  const to = String(m.to || '');
  if (!isId(to) || typeof m.env !== 'string' || m.env.length > 60000) return;
  if (!accounts.has(to)) return send(ws, { type: 'callfail', to, reason: 'nouser' });
  const me = accounts.get(ws.id);
  const item = { type: 'call', q: newQ(), from: ws.id, env: m.env, ts: Date.now(), fpub: me.pub };
  const s = sessions.get(to);
  if (s && s.readyState === 1) send(s, item);
  else enqueue(to, item);
}

function onLookup(ws, m, ip) {
  const id = String(m.id || '');
  if (!hit('lk:' + ws.id, 60, 60000) || !hit('lki:' + ip, 200, 60000)) return send(ws, { type: 'err', code: 'rate' });
  const acc = isId(id) ? accounts.get(id) : null;
  send(ws, acc ? { type: 'lookup', id, exists: true, pub: acc.pub } : { type: 'lookup', id, exists: false });
}

async function onSetPass(ws, m) {
  if (!validAuth(m.auth) || !validAuth(m.old)) return send(ws, { type: 'err', code: 'bad' });
  if (!hit('sp:' + ws.id, 5, 600e3)) return send(ws, { type: 'err', code: 'rate' });
  const acc = await checkAuth(ws.id, m.old);
  if (!acc) return send(ws, { type: 'err', code: 'auth' });
  const salt = crypto.randomBytes(16);
  acc.salt = salt.toString('base64');
  acc.hash = (await scryptRaw(m.auth, salt)).toString('base64');
  markDirty('accounts');
  send(ws, { type: 'ok', for: 'setpass' });
}

async function onDelete(ws, m) {
  if (!validAuth(m.auth)) return send(ws, { type: 'err', code: 'bad' });
  if (!hit('dl:' + ws.id, 5, 600e3)) return send(ws, { type: 'err', code: 'rate' });
  const acc = await checkAuth(ws.id, m.auth);
  if (!acc) return send(ws, { type: 'err', code: 'auth' });
  const id = ws.id;
  accounts.delete(id);
  queues.delete(id);
  markDirty('accounts'); markDirty('queues');
  send(ws, { type: 'ok', for: 'delete' });
  sessions.delete(id);
  ws.id = null;
  setTimeout(() => { try { ws.close(1000, 'deleted'); } catch {} }, 200);
}

async function handle(ws, m, ip) {
  if (m.type === 'signup') return onSignup(ws, m, ip);
  if (m.type === 'login') return onLogin(ws, m, ip);
  if (!ws.id) return send(ws, { type: 'err', code: 'noauth' });
  switch (m.type) {
    case 'msg': return onMsg(ws, m);
    case 'rcpt': return onRcpt(ws, m);
    case 'call': return onCall(ws, m);
    case 'ack': return ackItem(ws.id, String(m.q || ''));
    case 'lookup': return onLookup(ws, m, ip);
    case 'ice': return send(ws, { type: 'ice', ice: iceServers(ws.id) });
    case 'setpass': return onSetPass(ws, m);
    case 'delete': return onDelete(ws, m);
    case 'ping': return send(ws, { type: 'pong' });
    default: return undefined;
  }
}

/* ---------- http (landing page + APK download) ---------- */
const MIME = {
  '.html': 'text/html; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.apk': 'application/vnd.android.package-archive', '.json': 'application/json; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8', '.ico': 'image/x-icon',
};
const server = http.createServer((req, res) => {
  const base = {
    'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer',
    'Content-Security-Policy': "default-src 'self'; style-src 'unsafe-inline'; img-src 'self' data:",
  };
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405, base); return res.end(); }
  let p;
  try { p = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch { res.writeHead(400, base); return res.end(); }
  if (p === '/health') { res.writeHead(200, { ...base, 'Content-Type': 'application/json' }); return res.end('{"ok":true}'); }
  if (p === '/') p = '/index.html';
  const file = path.normalize(path.join(PUBLIC_DIR, p));
  if (!file.startsWith(PUBLIC_DIR + path.sep)) { res.writeHead(403, base); return res.end(); }
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404, { ...base, 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Not found'); }
    const ext = path.extname(file).toLowerCase();
    const h = { ...base, 'Content-Type': MIME[ext] || 'application/octet-stream', 'Content-Length': st.size };
    if (ext === '.apk') h['Content-Disposition'] = 'attachment; filename="Rimvon.apk"';
    res.writeHead(200, h);
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).pipe(res);
  });
});

/* ---------- websocket ---------- */
const wss = new WebSocketServer({ server, maxPayload: MAX_PAYLOAD, perMessageDeflate: false });
wss.on('connection', (ws, req) => {
  const ip = clientIp(req);
  ws.isAlive = true;
  ws.id = null;
  ws.tokens = 60;
  ws.last = Date.now();
  ws.chain = Promise.resolve();
  ws.authTimer = setTimeout(() => { if (!ws.id) ws.close(4001, 'auth timeout'); }, 15000);
  ws.on('pong', () => { ws.isAlive = true; });
  ws.on('message', (raw, isBinary) => {
    if (isBinary) return;
    const now = Date.now();
    ws.tokens = Math.min(60, ws.tokens + (now - ws.last) / 100); // 10 msgs/sec sustained
    ws.last = now;
    if (ws.tokens < 1) return send(ws, { type: 'err', code: 'rate' });
    ws.tokens -= 1;
    if (!ws.id && raw.length > 4096) return ws.close(4002, 'too big');
    let m;
    try { m = JSON.parse(raw.toString()); } catch { return; }
    if (!m || typeof m.type !== 'string') return;
    ws.chain = ws.chain.then(() => handle(ws, m, ip)).catch((e) => {
      console.error('handler error:', e && e.message);
      send(ws, { type: 'err', code: 'internal' });
    });
  });
  ws.on('close', () => {
    clearTimeout(ws.authTimer);
    if (ws.id && sessions.get(ws.id) === ws) sessions.delete(ws.id);
  });
  ws.on('error', () => {});
});
setInterval(() => {
  for (const ws of wss.clients) {
    if (!ws.isAlive) { ws.terminate(); continue; }
    ws.isAlive = false;
    try { ws.ping(); } catch {}
  }
}, 30000).unref();

function shutdown() { flush(); process.exit(0); }
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

server.listen(PORT, HOST, () => console.log(`Rimvon server listening on ${HOST}:${PORT}`));
