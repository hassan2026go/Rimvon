const sharp = require('sharp');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const full = fs.readFileSync(path.join(__dirname, 'icon.svg'), 'utf8');
const inner = full.match(/<!-- chat bubble -->[\s\S]*<\/svg>/)[0].replace('</svg>', '');
const fg = (size) => Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 108" width="${size}" height="${size}"><g transform="translate(18 18) scale(${72/512})">${inner}</g></svg>`);
const round = (size) => Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}"><circle cx="${size/2}" cy="${size/2}" r="${size/2}" fill="#fff"/></svg>`);
(async () => {
  const dens = { mdpi: 1, hdpi: 1.5, xhdpi: 2, xxhdpi: 3, xxxhdpi: 4 };
  const res = path.join(root, 'android/app/src/main/res');
  for (const [d, k] of Object.entries(dens)) {
    const dir = path.join(res, 'mipmap-' + d);
    fs.mkdirSync(dir, { recursive: true });
    const s = Math.round(48 * k);
    const base = await sharp(Buffer.from(full)).resize(s, s).png().toBuffer();
    fs.writeFileSync(path.join(dir, 'ic_launcher.png'), base);
    fs.writeFileSync(path.join(dir, 'ic_launcher_round.png'),
      await sharp(base).composite([{ input: round(s), blend: 'dest-in' }]).png().toBuffer());
    fs.writeFileSync(path.join(dir, 'ic_launcher_foreground.png'),
      await sharp(fg(Math.round(108 * k))).png().toBuffer());
  }
  const pub = path.join(root, 'server/public');
  fs.mkdirSync(pub, { recursive: true });
  fs.writeFileSync(path.join(pub, 'icon.svg'), full);
  fs.writeFileSync(path.join(pub, 'icon-512.png'), await sharp(Buffer.from(full)).resize(512, 512).png().toBuffer());
  fs.writeFileSync(path.join(root, 'design/icon-512.png'), await sharp(Buffer.from(full)).resize(512, 512).png().toBuffer());
  fs.writeFileSync(path.join(root, 'design/icon-1024.png'), await sharp(Buffer.from(full)).resize(1024, 1024).png().toBuffer());
  console.log('done');
})();
